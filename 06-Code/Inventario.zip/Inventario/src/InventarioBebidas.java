import java.util.ArrayList;

public class InventarioBebidas {
    private ArrayList<Bebida> inventario;

    public InventarioBebidas() {
        inventario = new ArrayList<>();
    }

    public void agregarBebida(String nombre, String tipo, double precio, int cantidad) {
        inventario.add(new Bebida(nombre, tipo, precio, cantidad));
        System.out.println("Bebida agregada con éxito.");
    }

    public void eliminarBebida(String nombre) {
        boolean encontrada = false;
        for (int i = 0; i < inventario.size(); i++) {
            if (inventario.get(i).getNombre().equalsIgnoreCase(nombre)) {
                inventario.remove(i);
                System.out.println("Bebida eliminada con éxito.");
                encontrada = true;
                break;
            }
        }
        if (!encontrada) {
            System.out.println("Bebida no encontrada.");
        }
    }

    public void listarBebidas() {
        if (inventario.isEmpty()) {
            System.out.println("El inventario está vacío.");
        } else {
            for (Bebida bebida : inventario) {
                System.out.println(bebida);
            }
        }
    }

    public void buscarBebida(String nombre) {
        for (Bebida bebida : inventario) {
            if (bebida.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Bebida encontrada: " + bebida);
                return;
            }
        }
        System.out.println("Bebida no encontrada.");
    }
}