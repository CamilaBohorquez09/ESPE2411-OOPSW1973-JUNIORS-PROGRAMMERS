import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        InventarioBebidas inventario = new InventarioBebidas();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Menu de Inventario de Bebidas ---");
            System.out.println("1. Agregar bebida");
            System.out.println("2. Eliminar bebida");
            System.out.println("3. Listar bebidas");
            System.out.println("4. Buscar bebida");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer

            switch (opcion) {
                case 1:
                    System.out.print("Nombre de la bebida: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Tipo de bebida: ");
                    String tipo = scanner.nextLine();
                    System.out.print("Precio de la bebida: ");
                    double precio = scanner.nextDouble();
                    System.out.print("Cantidad disponible: ");
                    int cantidad = scanner.nextInt();
                    inventario.agregarBebida(nombre, tipo, precio, cantidad);
                    break;
                case 2:
                    System.out.print("Nombre de la bebida a eliminar: ");
                    String nombreEliminar = scanner.nextLine();
                    inventario.eliminarBebida(nombreEliminar);
                    break;
                case 3:
                    inventario.listarBebidas();
                    break;
                case 4:
                    System.out.print("Nombre de la bebida a buscar: ");
                    String nombreBuscar = scanner.nextLine();
                    inventario.buscarBebida(nombreBuscar);
                    break;
                case 5:
                    System.out.println("Saliendo del programa.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }
}